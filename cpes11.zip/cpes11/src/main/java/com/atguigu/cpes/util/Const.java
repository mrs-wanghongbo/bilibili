package com.atguigu.cpes.util;

public interface Const {

	public final static String  SESSION_USER = "suser";
	
	public final static String  SESSION_MENU = "smenus";
}
